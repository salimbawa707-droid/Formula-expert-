# ACCEPTANCE TEST MATRIX — MUST PASS BEFORE RELEASE

## A. Unknown active matter
- Unknown ingredient with no active matter: result is UNKNOWN; no silent 100 or 0.
- Known water: 0 active only when identity is confirmed.
- SLES 28% vs SLES 70%: grade-specific active values remain distinct.
- Missing active matter cannot produce a verified active-surfactant total, HLB blend, CPI, or PASS.
- Invalid values (<0, >100, NaN, string garbage) are rejected.

## B. pH convergence and propagation
- Valid converged formulation: pH returned with provenance and convergence metadata.
- Non-converged solver: pH unavailable; no 7.0 result substitution.
- Empty formula: pH unavailable.
- Downstream compatibility/viscosity/lab-health/regulatory/specification engines cannot convert unknown pH into PASS.
- Solver initial guess may exist internally but cannot become output or evidence.

## C. Ingredient research
- Unknown ingredient name does not produce invented active matter/pH/density/HLB/CAS.
- Generic homepage cannot qualify as property evidence.
- AI response cannot auto-promote a property to verified.
- Client cannot forge `VERIFIED` status or bypass independent review.
- Offline app can resolve known local master-library entries without a network.

## D. HLB and chelation
- Unknown active matter does not silently enter a numeric verified weighted average.
- Ionic Davies values are not averaged with nonionic Griffin values.
- Explicit user override provenance is USER_OVERRIDE.
- Non-surfactants are not included as surfactants without valid classification.
- Unknown chelator capacity/active content yields insufficient data.
- Units and CaCO3-equivalent basis are tested.

## E. Specification and routing
- Missing category/template/parameter blocks PASS.
- Empty specification template cannot return VALID.
- Predicted result is not silently treated as measured.
- Powder does not receive liquid-only viscosity checks.
- Liquid does not receive powder-only bulk-density checks unless applicable.
- DISHWASH_AUTOMATIC physical forms are explicit and consistently routed.

## F. Offline and security
- Start app with network disabled and no API keys.
- Complete formula entry, calculation, save, reopen, export, and report workflow offline.
- Verify no runtime calls to Gemini/OpenAI/PubChem/Firebase/Supabase or other external services in core workflow.
- Every server endpoint has documented access policy, validation, and tests.
- Forged ingredient verification requests are rejected.
- No secrets in web build or APK.

## G. Persistence and release
- Data persists after app restart.
- Backup/restore and import/export round-trip tests pass.
- Currency calculations use integer paise or decimal-safe arithmetic.
- Clean web build passes.
- Android build passes if Android release is claimed.
- Regression suite passes from a clean checkout.
- Test manifest is generated from actual run, with exact suite/assertion counts.
- Laboratory gate remains NOT VALIDATED/PENDING unless actual controlled lab evidence and independent review are complete.

## Release decision
All software/security/offline/persistence/build gates must pass for `SOFTWARE READY — LAB VALIDATION PENDING`.
`RELEASE READY` must not be used when any applicable gate is open or not tested.
