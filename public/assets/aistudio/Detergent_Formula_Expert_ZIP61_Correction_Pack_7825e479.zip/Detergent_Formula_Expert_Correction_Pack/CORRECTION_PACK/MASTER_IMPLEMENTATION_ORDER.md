# MASTER IMPLEMENTATION ORDER — DETERGENT FORMULA EXPERT
## Final Defect Closure & Independent Release Re-Audit (Based on ZIP 61)

You are modifying the supplied Detergent Formula Expert project. The supplied project is the source tree to correct. Do not merely write another audit report. Implement the corrections in the actual source code, add regression tests, execute them, and provide verifiable evidence.

## 0. NON-NEGOTIABLE PROJECT CONTRACT

1. Preserve the existing 13 canonical product-category IDs and all mathematically defensible calculation logic.
2. The application must operate fully offline and must not require Gemini, OpenAI, PubChem, Supabase, Firebase, or any external API key for its core formulation, calculation, formula-library, inventory, batch, and report workflows.
3. Do not invent ingredient properties, purity, active matter, pH, density, HLB, viscosity, CAS identity, costs, or regulatory status.
4. Every scientific input/result must be clearly classified as one of:
   - `MEASURED` / `LAB_MEASURED`
   - `SUPPLIER_DOCUMENTED`
   - `DERIVED` (with equation, inputs, units, and assumptions)
   - `MODEL_PREDICTED` (with model identity and limitations)
   - `ESTIMATED` (never eligible for verified PASS)
   - `UNKNOWN` / `UNAVAILABLE`
5. Unknown is not zero, 100%, neutral pH, or any other substitute number. Do not use unknown values in calculations that require them. Return an explicit incomplete/blocked result with missing-input diagnostics.
6. Never label data `VERIFIED`, `AUTHORITATIVE`, `LAB_VALIDATED`, or `PASS` merely because a fallback, heuristic, generic homepage, AI response, or software test exists.
7. Do not delete or rewrite mathematically sound engines just to make tests pass. Refactor carefully and preserve correct equations.
8. Do not weaken tests, skip tests, alter expected values arbitrarily, or hardcode success statuses.
9. Do not claim laboratory validation without genuine laboratory observations and the required independent human review.
10. Documentation must reflect actual code and actual executed test/build results. Do not certify work that was not performed.

## 1. REQUIRED WORKFLOW

Work in controlled stages. For each stage:
- inspect callers and data contracts before editing;
- implement the source-code fix;
- add regression tests for normal, boundary, missing, invalid, and adversarial inputs;
- run focused tests;
- run the complete regression suite;
- run typecheck/lint/build and Android build where configured;
- record exact command, date/time, exit code, and test counts;
- independently inspect the final diff;
- update the defect register with `FIXED`, `PARTIAL`, or `BLOCKED`, plus file/line evidence.

Do not mark a stage complete merely because a test file exists or a report says PASS.

## 2. P0 — SCIENTIFIC INPUT INTEGRITY (BLOCKING)

### P0-A. Remove unknown active-matter defaults
Primary inspected locations:
- `src/utils/orchestrator/scientificExecutionDAG.ts` around lines 320–337
- `src/utils/analysisWorkflowEngine.ts` (search all occurrences of `activeMatterPct ?? 100`, `activePercent ?? 100`, and purity fallbacks)
- `src/utils/hlbEngine.ts` around lines 178–186
- `src/utils/chelatorEngine.ts` around line 737
- `src/App.tsx` scanned-ingredient handling around lines 592–596
- `server.ts` ingredient-research fallback and apply-verified route

Requirements:
- Remove `?? 100` and implicit 100% purity assumptions for unknown ingredients.
- Resolve active matter only from explicit user-supplied value, traceable supplier document, or a canonical library value with documented provenance and grade identity.
- If no defensible value exists, store `null`/undefined plus an explicit unknown status; do not silently convert to 0 or 100.
- Water may be 0% active only when the ingredient is confidently identified as water; this is a semantic fact, not a generic fallback.
- Preserve commercial grades separately (e.g. SLES 28% and SLES 70%).
- Validate range 0–100 and reject malformed values.
- Do not let unknown active matter create a numeric verified active-surfactant total, HLB blend, CPI, or specification PASS. A clearly labelled partial calculation may be shown only if its incompleteness is propagated.

### P0-B. Remove fabricated pH fallbacks
Search all source for `?? 7`, `|| 7`, `: 7.0`, `phVal = 7.0`, `initialGuess: 7.0`, and similar patterns. Do not blindly remove legitimate numerical solver initial guesses; distinguish solver initialization from published result substitution.
Inspected examples:
- `src/utils/orchestrator/scientificExecutionDAG.ts`: `state.finalEquilibriumPH ?? 7.0`
- `src/utils/analysisWorkflowEngine.ts`: advanced pH result fallback to 7
- `src/utils/viscosityEngine.ts`: calculated pH fallback to 7.0
- `src/utils/labHealthEngine.ts`: fallback to 7.0 after missing/failed pH
- `src/domain/regulatory/regulatoryComplianceEngine.ts`: `input.calculatedPH ?? 7.0`
- `src/domain/ph/pHEngineV2.ts`: non-converged evaluation uses 7.0 internally

Requirements:
- A solver initial guess may remain as a numerical algorithm parameter, but must never be returned or represented as a calculated pH.
- If solver does not converge, result pH must be `null`/undefined or an explicit unavailable state, never 7.
- Downstream compatibility, viscosity, lab-health, regulatory, specification, and CPI engines must receive `UNKNOWN` pH and return `INSUFFICIENT_DATA`/`BLOCKED` when pH is required.
- If an internal solver needs an evaluation point for diagnostics, mark it strictly internal and prevent it leaking into result fields, scores, verdicts, or provenance.
- Add regression tests proving failed/non-converged pH cannot produce a neutral pH, compatibility PASS, regulatory PASS, or viscosity PASS.

### P0-C. Remove false ingredient research and verification
Primary location: `server.ts`, especially `/api/ai/research-ingredient` around lines 344–410 and `/api/ai/apply-verified-ingredient` around lines 489 onward.

Observed issues:
- Heuristic ingredient fallback initializes active matter to 100, pH to 7, density to 1.0.
- Ingredient-name heuristics assign properties and confidence without grade-specific source evidence.
- Generic ECHA homepage may be used as a source URL.
- `previousRecord?.activeDefault ?? 100` can preserve/create an unsupported purity.
- Research route depends on GoogleGenAI.

Requirements:
- Core ingredient resolution must be deterministic and local.
- Remove heuristic generation of chemical properties from ingredient name alone.
- A name match can suggest a candidate identity but cannot verify active matter, pH, density, HLB, CAS, or supplier grade.
- No generic homepage as evidence. Every source record must identify an exact accessible document/page, publisher, title, date/version where available, and exact property supported.
- If external research functionality is retained as optional, it must be isolated from core calculations, disabled by default, and never be required for offline operation.
- `apply-verified-ingredient` must validate evidence and provenance, not trust client-provided `status: VERIFIED`.
- No promotion to authoritative/verified without required review and traceable evidence.
- Remove any `HIGH_CONFIDENCE_MATCH` default that is assigned merely because a field is missing.

### P0-D. HLB and chelation data integrity
Primary locations:
- `src/utils/hlbEngine.ts`
- `src/utils/chelatorEngine.ts`

Requirements:
- Unknown active matter remains unknown and cannot contribute a verified active-weight blend.
- Do not label explicit user override as supplier-reported unless the user actually attached a supplier source. Use `USER_OVERRIDE` provenance.
- Do not mix Griffin and Davies scales in one weighted average. Preserve the existing scale-separation improvement, but validate the scientific applicability and avoid describing ionic Davies output as directly equivalent to Griffin HLB.
- Check whether HLB is applicable to each material; builders/salts must not be treated as surfactants simply because a numeric override exists without classification.
- Chelation calculations must require documented chelator identity, active content, stoichiometry/capacity basis, and units. Unknown active content/capacity must return incomplete, not 100%.
- Do not turn estimated chelation capacities into verified results.
- Add tests for mixed ionic/nonionic systems, missing HLB, unknown active matter, non-surfactants, grade variants, and unknown chelator capacity.

### P0-E. One authoritative calculation path and truthful verdicts
Primary locations:
- `src/utils/orchestrator/scientificExecutionDAG.ts`
- `src/utils/analysisWorkflowEngine.ts`
- `src/utils/test-calculations.ts`
- all downstream engine callers

Requirements:
- Identify and document the single authoritative orchestration path for a formula check.
- Remove duplicate/conflicting calculations or make secondary calculations explicit diagnostic-only outputs.
- Ensure the same formula snapshot, units, normalized ingredient identities, and input provenance flow through all engines.
- No downstream engine may independently substitute missing values.
- Every engine returns value + status + provenance + limitations + missing inputs.
- `VALID`/`PASS` requires all mandatory inputs and all applicable criteria to be supported. Missing required evidence must be `INSUFFICIENT_DATA`, not PASS.
- Unknown product category must block category-dependent calculations and verdicts.
- Preserve separate powder and liquid pathways; do not run liquid viscosity requirements for powders or powder bulk-density requirements for liquids unless explicitly applicable.
- Audit all call sites, not just the main DAG.

### P0-F. Specification evaluation
Primary location: `src/utils/orchestrator/scientificExecutionDAG.ts`, specification node around lines 878–908.

Requirements:
- Retain actual `evaluateSpecifications()` integration.
- Missing template, empty parameter list, missing measured data, missing calculated values, or unsupported estimates must not yield `VALID`.
- Verify category/form-specific specification templates are scientifically defensible and sourced.
- Do not treat model-predicted viscosity as a measured specification pass unless the specification explicitly allows model screening and labels it as such.
- Add tests for missing template, empty template, unknown category, missing pH, missing viscosity, missing active matter, failed solver, and powder/liquid mismatches.

## 3. P1 — SCIENTIFIC MODEL VALIDATION

### P1-A. pH / stoichiometry
- Review charge balance, acid/base equivalents, dissociation constants, temperature assumptions, ionic strength/activity corrections, and solver convergence.
- Verify units and molecular weights from traceable source records.
- Distinguish equilibrium pH prediction from measured final product pH.
- Never call predicted pH `LAB_MEASURED`.
- Add dimensional-analysis and conservation tests.

### P1-B. Hardness and chelation
- Validate water hardness units and CaCO3-equivalent basis.
- Verify chelator capacity values and active content by source.
- Test hardness load, dose, stoichiometry, safety margin, and boundary behavior.
- Unknown hardness/capacity must not create a numeric pass.

### P1-C. Viscosity
- Identify which equations are theoretical, empirical, or fitted.
- Do not claim reliable viscosity from pH alone.
- Require relevant formulation, temperature, shear/rheology, electrolyte, and measurement inputs for any model claiming quantitative prediction.
- Otherwise return qualitative/insufficient-data status.
- Model-predicted cP must not be treated as measured cP.

### P1-D. CPI / cleaning score
- Identify all coefficients, multipliers, bonuses, thresholds, and empirical constants.
- Each coefficient must have a traceable source, calibration dataset, or explicit `UNVALIDATED_MODEL_ASSUMPTION` status.
- Remove arbitrary coefficients (including unexplained multipliers such as 0.7) from verified scoring.
- CPI must not be described as experimentally validated without controlled wash-test data.
- Separate theoretical screening score from measured cleaning performance.

### P1-E. 13 canonical categories
- Preserve all 13 IDs.
- Resolve the documented `DISHWASH_AUTOMATIC` physical-form inconsistency between taxonomy and validation matrix.
- Do not assume automatic dishwash is liquid or powder universally; define supported physical forms explicitly if both are intended.
- Validate each category's physical form, pH range, active matter range, target properties, formula templates, and engine routing against authoritative technical requirements.
- If no reliable source exists, mark the target UNKNOWN/UNAVAILABLE; do not invent targets.

### P1-F. Evidence vault and human review
- Preserve measured, supplier-documented, derived, predicted, estimated, and unknown distinctions.
- Require independent second human reviewer where the workflow specifies it.
- AI-generated transcription is not an independent human review.
- Evidence extraction status must remain pending until required review is completed.
- Hash/checksum proves file integrity, not scientific truth.

## 4. P2 — OFFLINE, SECURITY, DATA, AND RELEASE ENGINEERING

### P2-A. Offline architecture
- Remove mandatory GoogleGenAI initialization and all external API calls from the core runtime.
- Audit imports, runtime fetches, service workers, analytics, telemetry, auth, cloud database, remote fonts, CDN scripts, and package scripts.
- Core app must start and complete formula workflows with network disconnected and no API keys.
- Optional integrations must be disabled by default and clearly separated.
- Do not claim offline merely because calculations are local if app startup or key workflows call remote services.

### P2-B. Server/API security
Primary file: `server.ts`; helper files include `src/services/serverSecurity.ts`, `src/services/authProviderConfig.ts`, `src/services/firebaseAuthClient.ts`.

- Inventory every endpoint and classify public/private.
- Apply actual authentication and authorization middleware where needed.
- Validate request schema, size, types, and allowed values.
- Add rate limiting, safe error responses, security headers, and CSRF protections where relevant.
- Do not expose stack traces, secrets, or sensitive details.
- Verify CORS/origin policy.
- Protect ingredient apply/verification routes from forged client claims.
- If backend endpoints are unnecessary for offline build, remove them or keep them out of the core application.
- Add endpoint security regression tests.

### P2-C. Persistence, backup, and recovery
- Verify the actual database used at runtime; do not certify IndexedDB/SQLite if data remains in-memory.
- Test create/read/update/delete, migrations, transaction rollback, backup, restore, export/import, schema versioning, and corruption recovery.
- Avoid silent data loss.
- Use integer paise or decimal-safe arithmetic for currency; do not use binary floating point for financial totals without controlled rounding.
- Ensure backups include formulas, ingredient library changes, evidence metadata, batch records, and inventory as applicable.

### P2-D. Android and web builds
- Build from a clean checkout with documented supported versions.
- Verify no secret keys embedded in web bundles or APK.
- Inspect Android permissions and network security config.
- Verify app behavior offline on a real device/emulator.
- Record APK/AAB artifact hash and build environment.
- Do not claim Android certification without an actual successful build and smoke test.

## 5. P3 — RELEASE GATES (ALL MUST PASS)

Release is BLOCKED until every gate below has reproducible evidence:

A. Software integrity: typecheck, lint, all regression suites, no skipped critical tests.
B. Scientific integrity: no fabricated defaults; provenance and unknown propagation verified.
C. Laboratory validation: clearly state NOT VALIDATED unless genuine lab evidence and independent review are complete.
D. Security/privacy: endpoint and dependency audit passed; no exposed secrets.
E. Offline operation: core workflows verified with network disabled and no API keys.
F. Persistence: real data persistence, backup and restore tested.
G. Web release: clean production build and offline smoke test.
H. Android release: clean build, permission review, offline smoke test.
I. Documentation: all statements match actual source and executed evidence.

A gate may be `PASS`, `FAIL`, `PARTIAL`, or `NOT TESTED`. Never turn `NOT TESTED` into PASS. If empirical lab work is pending, the application may be software-ready for controlled testing, but it is not experimentally validated.

## 6. REQUIRED DELIVERABLES

Create and maintain:
1. `FINAL_DEFECT_REGISTER.md` — each defect, severity, source location, fix, tests, status.
2. `SCIENTIFIC_DATA_PROVENANCE_MATRIX.csv` — each calculated input/property, source, method, uncertainty, status.
3. `ENGINE_DEPENDENCY_AND_CALLER_MAP.md` — authoritative engine and all callers.
4. `OFFLINE_DEPENDENCY_AUDIT.md` — all external network/dependency paths and disposition.
5. `SECURITY_ENDPOINT_MATRIX.md` — endpoint auth, validation, rate limit, tests.
6. `LAB_EVIDENCE_STATUS.md` — measured vs predicted vs pending independent review.
7. `TEST_EXECUTION_EVIDENCE.md` — exact commands, environment, timestamps, exit codes, counts.
8. `FINAL_RELEASE_READINESS_MATRIX.md` — honest gate-by-gate verdict.
9. Updated user documentation.
10. Actual code changes and regression tests.

## 7. FINAL RESPONSE FORMAT REQUIRED FROM YOU

At completion, report:
- files changed and why;
- defects fixed vs still open;
- exact tests/builds actually executed and results;
- all blocked items and why;
- confirmation whether network-disabled core workflow was tested;
- confirmation whether Android build was actually produced;
- confirmation whether any lab validation is genuine or still pending;
- final release verdict: `RELEASE READY`, `SOFTWARE READY — LAB VALIDATION PENDING`, or `NOT RELEASE READY`.

Do not state 100%, certified, production-ready, or all-green unless every applicable gate has reproducible evidence.
