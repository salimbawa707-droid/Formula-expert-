# DEFECT REGISTER — ZIP 61 BASELINE

Audit baseline: `formula-expert- (61).zip`
Audit method: ZIP integrity check, source-tree comparison against ZIP 60, targeted source inspection, report/manifest inspection, and attempted local build/test commands.
Important limitation: fresh build/test commands could not execute in the audit container because `vite`/`bun` returned `Permission denied`. Therefore no fresh build or test PASS is claimed.

| ID | Severity | Location / evidence | Finding | Required closure |
|---|---|---|---|---|
| DFE-001 | CRITICAL | `src/utils/orchestrator/scientificExecutionDAG.ts` ~323–337 | Unknown active matter can resolve to `matchedUniv.activeDefault ?? matchedUniv.activeMatter ?? 100`; fallback assumptions also recorded. | Propagate UNKNOWN; no numeric active matter unless defensible source. |
| DFE-002 | CRITICAL | `src/utils/analysisWorkflowEngine.ts` | `ing.activeMatterPct ?? 100` / purity fallback. | Remove unsupported purity default and propagate missing status. |
| DFE-003 | CRITICAL | `src/utils/hlbEngine.ts` ~178–186 | `activeMatterPct` initialized to 100 for unresolved non-water ingredients. | Unknown active matter must not enter weighted HLB as verified. |
| DFE-004 | CRITICAL | `src/utils/chelatorEngine.ts` ~737 | Active-content fallback to 100 identified. | Require sourced active content/capacity or return incomplete. |
| DFE-005 | CRITICAL | `src/utils/orchestrator/scientificExecutionDAG.ts` ~582 | Missing final pH becomes 7.0 for compatibility. | UNKNOWN pH must yield insufficient data where required. |
| DFE-006 | CRITICAL | `src/utils/analysisWorkflowEngine.ts` | Missing advanced pH falls back to 7. | Do not publish/use fallback as calculated pH. |
| DFE-007 | HIGH | `src/utils/viscosityEngine.ts` | Missing calculated pH falls back to 7.0. | Propagate unavailable pH and model limitations. |
| DFE-008 | HIGH | `src/utils/labHealthEngine.ts` ~62–76 | Missing/failed pH becomes 7.0. | No neutral pH substitution in health score. |
| DFE-009 | HIGH | `src/domain/regulatory/regulatoryComplianceEngine.ts` ~61 | Missing calculated pH becomes 7.0. | Regulatory classification must report insufficient data. |
| DFE-010 | HIGH | `src/domain/ph/pHEngineV2.ts` ~45–53 | Non-converged solver uses evaluation pH 7 internally. | Ensure internal diagnostic point cannot leak into result/verdict/provenance. |
| DFE-011 | CRITICAL | `server.ts` ~344–410 | Heuristic ingredient fallback assigns defaults including active matter, pH, density, HLB. | Remove property invention from name-only heuristics. |
| DFE-012 | CRITICAL | `server.ts` ingredient research flow | Generic ECHA homepage may be represented as a source; verification/confidence can be promoted without exact evidence. | Exact source-to-property provenance and human review. |
| DFE-013 | CRITICAL | `server.ts` ~489 onward | Apply-verified path can use `previousRecord?.activeDefault ?? 100`. | Reject unsupported values and forged verification claims. |
| DFE-014 | CRITICAL | `server.ts` ~1–22 | Mandatory GoogleGenAI import/initialization; `GEMINI_API_KEY` integration. | Remove from core/offline runtime or isolate optional integration. |
| DFE-015 | HIGH | `package.json`, `metadata.json`, service files | Google GenAI, Firebase, Supabase dependencies/capabilities remain; `scienceService.ts` has PubChem requests. | Audit every runtime path; core must work offline without keys/network. |
| DFE-016 | CRITICAL | `server.ts` routes | POST endpoints found without visible route-level auth middleware in this file. | Trace middleware and enforce actual auth/authorization/validation. |
| DFE-017 | HIGH | `src/utils/orchestrator/scientificExecutionDAG.ts` specification node | Specification integration improved, but missing template/empty parameters/unsupported model values need explicit insufficient-data tests. | Add negative regression tests; no empty-template PASS. |
| DFE-018 | HIGH | `src/utils/analysisWorkflowEngine.ts` | Separate calculations remain outside DAG; viscosity evaluation occurs before powder/liquid branching. | Establish one authoritative path and category-appropriate engine routing. |
| DFE-019 | HIGH | `src/utils/hlbEngine.ts` ~369–373 | Explicit user override is represented as `SUPPLIER_REPORTED` method metadata. | Distinguish USER_OVERRIDE from supplier-reported evidence. |
| DFE-020 | HIGH | `src/domain/productTaxonomy.ts` DISHWASH_AUTOMATIC and P1 matrix | Physical-form inconsistency: taxonomy says LIQUID while validation matrix reportedly labels POWDER/TAB. | Reconcile supported forms and routing without guessing. |
| DFE-021 | HIGH | P1/P3 lab reports and evidence status | Software test status is not empirical laboratory validation; provisional datasets remain. | Keep empirical gate pending until genuine data and independent review. |
| DFE-022 | HIGH | P0–P3 reports and manifests | Reported counts differ (e.g. 131 modules/4,649 vs stored manifest 130/4,585); manifest timestamp predates final reports. | Re-run current suite and regenerate manifest from actual execution. |
| DFE-023 | HIGH | P3 release matrix | Gate C called PASS while laboratory certification says empirical datasets provisional. | Correct release matrix and all claims. |
| DFE-024 | HIGH | `src/utils/test-calculations.ts` and test suite | New P0 suite registered, but registration is not proof of successful current execution. | Execute all suites in clean environment; preserve logs and exit codes. |
| DFE-025 | HIGH | Build/test environment | Fresh `npm run build`, `npm test`, `npm run test:all` did not execute successfully in audit environment (`vite`/`bun`: Permission denied). | Re-run in supported clean environment; do not claim pass from archived reports. |

## ZIP 60 → ZIP 61 comparison

- ZIP 60: 693 files.
- ZIP 61: 729 files.
- ZIP 61 added 36 files: 35 P0–P3 documentation/report files and one P0 regression test.
- No existing files were removed.
- Only four existing source files changed: `src/App.tsx`, `src/utils/hlbEngine.ts`, `src/utils/orchestrator/scientificExecutionDAG.ts`, `src/utils/test-calculations.ts`.
- Actual improvements observed: HLB ionic/Griffin separation, specification engine integration, unknown-category blocking, scanned ingredient active matter lookup helper.
- This is not proof that the remaining P0–P3 workstreams are complete.

## Audit caution

Line numbers are approximate and may shift after edits. Search for the exact expressions and inspect all callers, not just the listed lines.
