#!/usr/bin/env python3
"""
Genuine Android Capacitor Release APK Build Pipeline
Runs:
1. Pre-flight tool & keystore environment validation
2. Web production build (bun run build)
3. Capacitor sync (validates and copies web dist/ to the Android project)
4. Genuine Gradle release build (./gradlew assembleRelease in android/)
5. APK signing via externally supplied keystore (apksigner)
6. Signature & integrity verification
7. Copies genuine output to release-artifacts/detergent-formula-expert-release.apk

Fails non-zero if ANY step or required tool/credential is missing.
Does NOT generate fake APKs, self-signed keys, or placeholder outputs.
"""

import os
import sys
import shutil
import subprocess

PROJECT_ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
ANDROID_DIR = os.path.join(PROJECT_ROOT, "android")
RELEASE_ARTIFACTS_DIR = os.path.join(PROJECT_ROOT, "release-artifacts")


def find_android_tool(tool_name):
    """Find an Android SDK build tool on PATH or in the installed SDK."""
    executable = shutil.which(tool_name)
    if executable:
        return executable

    sdk_roots = [
        os.environ.get("ANDROID_SDK_ROOT"),
        os.environ.get("ANDROID_HOME"),
        "/opt/android-sdk",
        "/usr/local/lib/android/sdk",
    ]
    for sdk_root in dict.fromkeys(root for root in sdk_roots if root):
        build_tools_dir = os.path.join(sdk_root, "build-tools")
        if not os.path.isdir(build_tools_dir):
            continue
        versions = sorted(
            (name for name in os.listdir(build_tools_dir)
             if os.path.isdir(os.path.join(build_tools_dir, name))),
            key=lambda version: tuple(int(part) for part in version.split(".") if part.isdigit()),
            reverse=True,
        )
        for version in versions:
            candidate = os.path.join(build_tools_dir, version, tool_name)
            if os.path.isfile(candidate):
                return candidate
    return None

def check_environment():
    """Validates availability of JDK, Gradle/Gradlew, Android SDK tools, and release credentials."""
    errors = []

    # 1. Check JDK
    if not shutil.which("javac") or not shutil.which("java"):
        errors.append("JDK is missing ('java' / 'javac' not found in PATH)")

    # 2. Check Android Gradle / Gradlew
    gradlew = os.path.join(ANDROID_DIR, "gradlew")
    has_gradle = shutil.which("gradle") or os.path.exists(gradlew)
    if not has_gradle:
        errors.append("Gradle build tool is missing (neither system 'gradle' nor './android/gradlew' found)")

    # 3. Check Android SDK build tools across installed SDK versions
    aapt2 = find_android_tool("aapt2")
    apksigner = find_android_tool("apksigner")
    if not aapt2 or not apksigner:
        errors.append("Android SDK build tools ('aapt2' / 'apksigner') are not available in environment")

    # 4. Check External Signing Environment Variables
    keystore_path = os.environ.get("KEYSTORE_PATH")
    keystore_store_pass = os.environ.get("KEYSTORE_STORE_PASS")
    keystore_key_pass = os.environ.get("KEYSTORE_KEY_PASS")

    if not keystore_path or not keystore_store_pass or not keystore_key_pass:
        errors.append("RELEASE BUILD BLOCKED: external signing credentials unavailable (KEYSTORE_PATH, KEYSTORE_STORE_PASS, KEYSTORE_KEY_PASS)")
    elif not os.path.exists(keystore_path):
        errors.append(f"RELEASE BUILD BLOCKED: release keystore file not found at '{keystore_path}'")

    return errors


def build_release():
    print("================================================================")
    print("  GENUINE ANDROID CAPACITOR RELEASE APK BUILD PIPELINE          ")
    print("================================================================")

    # 1. Pre-flight Environment Validation
    errors = check_environment()
    if errors:
        print("\n❌ ANDROID RELEASE BUILD BLOCKED BY MISSING ENVIRONMENT / CREDENTIALS:")
        for err in errors:
            print(f"  - {err}")
        print("\nSecurity & Release Policy Enforcement:")
        print("  - Refusing to create fake, minimal, or synthetic APKs.")
        print("  - Refusing to generate self-signed keystores or hardcoded credentials.")
        sys.exit(1)

    apksigner = find_android_tool("apksigner")
    if not apksigner:
        print("❌ Android SDK apksigner was not found.")
        sys.exit(1)

    # 2. Web Production Build
    print("\n=== STEP 1: Running Web Production Build ===")
    try:
        subprocess.run(["bun", "run", "build"], cwd=PROJECT_ROOT, check=True)
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Web production build failed: {e}")
        sys.exit(1)

    # 3. Capacitor Sync / Copy
    print("\n=== STEP 2: Synchronizing web assets through Capacitor ===")
    dist_dir = os.path.join(PROJECT_ROOT, "dist")
    if not os.path.isdir(dist_dir):
        print("❌ Production web assets are missing; the web build did not produce dist/.")
        sys.exit(1)
    try:
        subprocess.run(["bun", "run", "cap:sync"], cwd=PROJECT_ROOT, check=True)
    except (OSError, subprocess.CalledProcessError) as e:
        print(f"❌ Capacitor sync failed: {e}")
        sys.exit(1)

    public_assets_dir = os.path.join(ANDROID_DIR, "app", "src", "main", "assets", "public")
    if not os.path.isdir(public_assets_dir):
        print(f"❌ Capacitor did not produce Android web assets at '{public_assets_dir}'")
        sys.exit(1)

    # Automated Release Artifact Verification Check
    print("=== Artifact Verification: Checking Android public assets ===")
    prohibited_found = []
    for root, dirs, files in os.walk(public_assets_dir):
        for file in files:
            if file == "server.cjs" or file.endswith(".cjs") or file.endswith(".map"):
                bad_path = os.path.join(root, file)
                prohibited_found.append(bad_path)
    if prohibited_found:
        print(f"❌ ERROR: Prohibited backend artifacts found in Android public assets: {prohibited_found}")
        sys.exit(1)
    print("✓ Artifact verification passed: No server bundles or source maps present in Android public assets.")

    # 4. Genuine Gradle Release Build
    print("\n=== STEP 3: Executing Genuine Gradle Release Build ===")
    gradle_cmd = ["./gradlew", "assembleRelease"] if os.path.exists(os.path.join(ANDROID_DIR, "gradlew")) else ["gradle", "assembleRelease"]
    try:
        subprocess.run(gradle_cmd, cwd=ANDROID_DIR, check=True)
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Gradle release build failed: {e}")
        sys.exit(1)

    # 5. Signing via apksigner & External Keystore
    print("\n=== STEP 4: Signing APK via External Keystore ===")
    unsigned_apk = os.path.join(ANDROID_DIR, "app", "build", "outputs", "apk", "release", "app-release-unsigned.apk")
    if not os.path.exists(unsigned_apk):
        unsigned_apk = os.path.join(ANDROID_DIR, "app", "build", "outputs", "apk", "release", "app-release.apk")

    if not os.path.exists(unsigned_apk):
        print(f"❌ Error: Unsigned Gradle APK output not found at '{unsigned_apk}'")
        sys.exit(1)

    os.makedirs(RELEASE_ARTIFACTS_DIR, exist_ok=True)
    target_apk = os.path.join(RELEASE_ARTIFACTS_DIR, "detergent-formula-expert-release.apk")

    keystore_path = os.environ["KEYSTORE_PATH"]
    store_pass = os.environ["KEYSTORE_STORE_PASS"]
    key_pass = os.environ["KEYSTORE_KEY_PASS"]
    alias = os.environ.get("KEYSTORE_ALIAS", "detergent-expert")

    sign_cmd = [
        apksigner, "sign",
        "--ks", keystore_path,
        "--ks-pass", f"pass:{store_pass}",
        "--key-pass", f"pass:{key_pass}",
        "--ks-key-alias", alias,
        "--out", target_apk,
        unsigned_apk
    ]

    try:
        subprocess.run(sign_cmd, check=True)
    except subprocess.CalledProcessError as e:
        print(f"\n❌ APK signing failed: {e}")
        sys.exit(1)

    # 6. Verify Signature
    print("\n=== STEP 5: Verifying Signature Integrity ===")
    try:
        subprocess.run([apksigner, "verify", "--verbose", target_apk], check=True)
    except subprocess.CalledProcessError as e:
        print(f"\n❌ APK signature verification failed: {e}")
        sys.exit(1)

    print(f"\n✅ GENUINE RELEASE APK BUILT AND SIGNED SUCCESSFULLY: {target_apk}")


if __name__ == "__main__":
    build_release()
