# Detergent Formula Expert — Correction Pack

This archive contains:
1. The complete supplied ZIP 61 project source tree, unchanged at baseline.
2. `CORRECTION_PACK/MASTER_IMPLEMENTATION_ORDER.md` — paste/use as the primary instruction for Google AI Studio or your coding agent.
3. `CORRECTION_PACK/DEFECT_REGISTER.md` — source-backed baseline defects.
4. `CORRECTION_PACK/ACCEPTANCE_TEST_MATRIX.md` — required tests and release gates.

## How to give this to Google

Upload this ZIP and instruct the coding agent:

"Read `CORRECTION_PACK/MASTER_IMPLEMENTATION_ORDER.md` completely. Implement every correction in the actual application source code. Do not only generate reports. Work in stages, preserve scientifically defensible logic, add regression tests, run all tests/builds, and update the defect register with exact evidence. Do not claim PASS for untested or laboratory-unvalidated work."

## Important

- This is a correction instruction package, not a claim that the source has already been fixed.
- The original application source files are included as the baseline.
- The baseline audit found serious unresolved scientific-integrity, offline, and security issues.
- Do not publish the application until the required gates are independently verified.
- Laboratory validation must remain pending until genuine lab data and independent review exist.
