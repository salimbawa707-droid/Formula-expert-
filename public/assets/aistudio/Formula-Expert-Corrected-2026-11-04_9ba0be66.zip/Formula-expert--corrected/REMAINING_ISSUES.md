# Remaining Issues / Manual Follow-up

**Status:** Open items after code-level correction.

## P1 — Account deletion endpoint missing
Frontend `src/services/supabaseClient.ts` calls `DELETE /api/account`. The correction adds an authenticated fail-closed HTTP 501 response so the app cannot mistake a missing route for successful deletion. Actual deletion is still not implemented. Do not replace this with a success-only stub. Implement with a provider-aware identity strategy, verified owner UID, correct Firebase/Supabase admin deletion, owned-data deletion or retention rules, idempotency, audit logging without secrets, and tests. Confirm whether both auth providers and associated user tables must be deleted.

## P1 — Full tests/build not yet run
Install dependencies using the project’s intended Bun workflow in a controlled environment, run the existing test suites, run the production build, then test login-protected API routes. This correction environment could only run static checks and syntax checks.

## P1 — Android release evidence missing
Build a debug APK and test it on a real device/emulator. Verify `VITE_API_BASE_URL`, HTTPS, auth token forwarding, image upload limits, and API server reachability. Release signing and Play Console verification require separate secure configuration.

## P1 — Production rate limit store
Current rate limiting is process-local. Configure a shared store (e.g., Redis) and a trusted-proxy policy for horizontal scaling/serverless hosting. Avoid enabling trust proxy for arbitrary client-supplied forwarded headers.

## P1 — Google Play verification configuration
Configure and test the Google Play Developer API service account, package ID `com.detergentrnd.formulaexpert`, allowed product IDs, durable purchase replay/grant storage, and account-to-purchase binding. Confirm all failure cases grant no entitlement.

## P1 — Scientific validation
- Independently review all 144 Pušić R460 source rows with a second human reviewer.
- Validate CPI coefficients against independent laboratory datasets.
- Use measured wash-water hardness for formula-specific chelation conclusions.
- Attach traceable sources to category pH/active-matter targets and commercial-grade assays.
- Do not mark AI research as VERIFIED solely because a URL/source label exists.
- Confirm formula performance, stability, preservation, material compatibility, and handling safety with appropriate lab work.

## P2 — Runtime/dependency verification
- Confirm deployment Node version is >=22.6.0.
- Run `npm run test:correction-static` (or `node scripts/verify-correction-static.mjs`).
- Run existing Bun tests and Vite build after dependencies are installed.
- Run an up-to-date dependency vulnerability scan against the lockfile; this correction package does not claim a completed scan.
- Test offline behavior separately; app still contains Gemini/Supabase/Firebase integrations and is not certified as fully offline.

## P2 — Operational observability
Keep detailed diagnostics in server logs only; ensure logs never include bearer tokens, purchase tokens, API keys, full uploaded labels, or private user data. Add request IDs and monitoring with a defined retention policy.
