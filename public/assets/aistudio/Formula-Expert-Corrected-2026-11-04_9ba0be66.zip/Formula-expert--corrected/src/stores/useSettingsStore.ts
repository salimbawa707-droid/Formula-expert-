import { create } from 'zustand';
import { db } from '../db/database';
import { CloudSyncService } from '../services/cloudSync';
import { clearPersistedAuthentication, hasPersistedSupabaseSession, isSupabaseConfigured } from '../services/authProviderConfig';
import { 
  auth as firebaseAuth, 
  signInWithGoogle as firebaseSignInWithGoogle, 
  signOutUser as firebaseSignOutUser
} from '../services/firebaseAuthClient';
import { onAuthStateChanged } from 'firebase/auth';

export type UserPlan = 'free' | 'pro_monthly' | 'pro_yearly' | 'team';

export interface TeamMember {
  email: string;
  name: string;
  role: 'owner' | 'chemist' | 'viewer';
  status: 'active' | 'invited';
  joinedAt: string;
}

export interface TeamWorkspace {
  id: string;
  name: string;
  ownerEmail: string;
  members: TeamMember[];
  createdAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  company: string;
  role: string;
  plan: UserPlan;
  isAuthenticated: boolean;
  trialEndsAt: string | null;
  trialActivated: boolean;
  subscriptionExpiresAt: string | null;
  teamWorkspace: TeamWorkspace | null;
}

export interface AISettings {
  provider: 'gemini' | 'openrouter';
  apiKey?: string;
  selectedModel?: string;
}

export type LabTheme = 'midnight' | 'daylight';

export interface AppPreferences {
  category: string;
  batchSizeKg: number;
  waterHardnessPpm: number | null;
  waterHardnessSource: 'USER_ENTERED' | 'MEASURED' | 'UNKNOWN';
  currencySymbol: string;
  theme: LabTheme;
}

export interface SyncState {
  lastSyncedAt: string | null;
  isSyncing: boolean;
  error: string | null;
  isCloudConnected: boolean;
}

export function applyTheme(theme: LabTheme): void {
  if (typeof document !== 'undefined') {
    const root = document.documentElement;
    if (theme === 'daylight') {
      root.classList.add('theme-daylight');
      root.setAttribute('data-theme', 'daylight');
    } else {
      root.classList.remove('theme-daylight');
      root.setAttribute('data-theme', 'midnight');
    }
    try {
      localStorage.setItem('detergent_lab_theme', theme);
    } catch {}
  }
}

// Immediately apply saved theme if in browser
if (typeof window !== 'undefined') {
  try {
    const initialTheme = (localStorage.getItem('detergent_lab_theme') as LabTheme) || 'midnight';
    applyTheme(initialTheme);
  } catch {}
}

interface SettingsStore {
  profile: UserProfile;
  aiSettings: AISettings;
  preferences: AppPreferences;
  syncState: SyncState;
  isLoading: boolean;

  loadSettings: () => Promise<void>;
  updateProfile: (profile: Partial<UserProfile>) => Promise<void>;
  updateAISettings: (settings: Partial<AISettings>) => Promise<void>;
  updatePreferences: (prefs: Partial<AppPreferences>) => Promise<void>;
  setTheme: (theme: LabTheme) => Promise<void>;
  toggleTheme: () => Promise<void>;

  // Real Auth & Subscription Actions
  signIn: (email: string, password?: string, name?: string) => Promise<void>;
  signUp: (email: string, password: string, name: string, company?: string) => Promise<{ confirmationRequired: boolean }>;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  activate7DayTrial: () => Promise<void>;
  upgradePlan: (plan: UserPlan) => Promise<void>;
  deleteAccount: () => Promise<void>;

  // Team Actions
  createTeamWorkspace: (teamName: string) => Promise<void>;
  inviteTeamMember: (email: string, role?: 'chemist' | 'viewer') => Promise<void>;
  removeTeamMember: (email: string) => Promise<void>;

  // Cloud Sync
  triggerCloudSync: () => Promise<void>;
}

const DEFAULT_PROFILE: UserProfile = {
  id: 'guest_local_user',
  name: 'Formulator Chemist',
  email: 'formulator@rnd-lab.com',
  company: 'Clean Tech Innovations',
  role: 'Senior R&D Chemist',
  plan: 'free',
  isAuthenticated: false,
  trialEndsAt: null,
  trialActivated: false,
  subscriptionExpiresAt: null,
  teamWorkspace: null,
};

const DEFAULT_AI_SETTINGS: AISettings = {
  provider: 'gemini',
  selectedModel: 'gemini-2.5-flash',
};

const DEFAULT_PREFERENCES: AppPreferences = {
  category: 'Liquid Laundry',
  batchSizeKg: 100,
  waterHardnessPpm: null,
  waterHardnessSource: 'UNKNOWN',
  currencySymbol: '$',
  theme: 'midnight',
};

let supabaseAuthListenerInitialized = false;
let firebaseAuthListenerInitialized = false;

export const useSettingsStore = create<SettingsStore>((set, get) => ({
  profile: DEFAULT_PROFILE,
  aiSettings: DEFAULT_AI_SETTINGS,
  preferences: DEFAULT_PREFERENCES,
  syncState: {
    lastSyncedAt: CloudSyncService.getStatus().lastSyncedAt,
    isSyncing: false,
    error: null,
    isCloudConnected: isSupabaseConfigured(),
  },
  isLoading: false,

  loadSettings: async () => {
    set({ isLoading: true });
    try {
      const profRec = await db.userSettings.get('user_profile');
      const aiRec = await db.userSettings.get('ai_settings');
      const prefRec = await db.userSettings.get('app_preferences');

      let currentProfile: UserProfile = profRec?.value ? { ...DEFAULT_PROFILE, ...profRec.value } : DEFAULT_PROFILE;
      // A persisted profile is display data only. Authentication must be re-established
      // from a live provider session on every startup; legacy local fallback profiles
      // must never survive as authenticated identities.
      currentProfile = clearPersistedAuthentication(currentProfile);

      // Check real Supabase session if configured
      if (isSupabaseConfigured() && hasPersistedSupabaseSession()) {
        try {
          const { supabase } = await import('../services/supabaseClient');
          const { data: { session } } = await supabase.auth.getSession();
          if (session?.user) {
            const u = session.user;
            const meta = u.user_metadata || {};
            currentProfile = {
              ...currentProfile,
              id: u.id,
              email: u.email || currentProfile.email,
              name: meta.name || currentProfile.name || u.email?.split('@')[0] || 'R&D Chemist',
              company: meta.company || currentProfile.company,
              plan: (meta.plan as UserPlan) || currentProfile.plan || 'free',
              isAuthenticated: true,
            };

            // Also check profiles table
            const { data: profileRow } = await supabase
              .from('profiles')
              .select('*')
              .eq('id', u.id)
              .single();

            if (profileRow) {
              currentProfile = {
                ...currentProfile,
                name: profileRow.name || currentProfile.name,
                company: profileRow.company || currentProfile.company,
                plan: (profileRow.plan as UserPlan) || currentProfile.plan,
                trialActivated: Boolean(profileRow.trial_activated),
                trialEndsAt: profileRow.trial_ends_at || currentProfile.trialEndsAt,
                subscriptionExpiresAt: profileRow.subscription_expires_at || currentProfile.subscriptionExpiresAt,
              };
            }
          }

          // Attach auth state change listener once
          if (!supabaseAuthListenerInitialized) {
            supabaseAuthListenerInitialized = true;
            supabase.auth.onAuthStateChange(async (event, newSession) => {
              if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'USER_UPDATED') {
                if (newSession?.user) {
                  const su = newSession.user;
                  const smeta = su.user_metadata || {};
                  const updatedProf: Partial<UserProfile> = {
                    id: su.id,
                    email: su.email || get().profile.email,
                    name: smeta.name || get().profile.name,
                    company: smeta.company || get().profile.company,
                    isAuthenticated: true,
                  };
                  get().updateProfile(updatedProf);
                  get().triggerCloudSync();
                }
              } else if (event === 'SIGNED_OUT') {
                const resetProf: UserProfile = {
                  ...DEFAULT_PROFILE,
                  isAuthenticated: false,
                };
                set({ profile: resetProf });
              }
            });
          }
        } catch (e) {
          console.warn('Supabase session check:', e);
        }
      }

      // Attach Firebase Auth state change listener once
      if (!firebaseAuthListenerInitialized) {
        firebaseAuthListenerInitialized = true;
        onAuthStateChanged(firebaseAuth, async (fbUser) => {
          if (fbUser) {
            const updatedProf: Partial<UserProfile> = {
              id: fbUser.uid,
              email: fbUser.email || get().profile.email,
              name: fbUser.displayName || get().profile.name,
              isAuthenticated: true,
            };
            await get().updateProfile(updatedProf);
            // Sync user profile & download cloud formulas/trials from Firestore
            try {
              const { syncUserProfile, getUserFormulas, getUserTrials } = await import('../services/firebaseClient');
              await syncUserProfile(fbUser);
              const userFormulas = await getUserFormulas(fbUser.uid);
              if (userFormulas && userFormulas.length > 0) {
                for (const f of userFormulas) {
                  await db.formulas.put(f);
                }
              }
              const userTrials = await getUserTrials(fbUser.uid);
              if (userTrials && userTrials.length > 0) {
                for (const t of userTrials) {
                  await db.labNotes.put({
                    id: t.id,
                    title: t.title,
                    text: t.observations,
                    date: t.updatedAt?.split('T')[0] || new Date().toISOString().split('T')[0],
                    formulaId: t.formulaId,
                    tags: ['FirestoreSync', t.stabilityVerdict || 'UNTESTED'],
                    createdAt: t.createdAt,
                    updatedAt: t.updatedAt
                  });
                }
              }
            } catch (syncErr) {
              console.warn("Firestore sync during auth change:", syncErr);
            }
            set({
              syncState: {
                ...get().syncState,
                isCloudConnected: true,
                lastSyncedAt: new Date().toLocaleTimeString(),
                isSyncing: false,
                error: null,
              }
            });
          } else if (!isSupabaseConfigured()) {
            const resetProfile: UserProfile = {
              ...get().profile,
              isAuthenticated: false,
            };
            set({ profile: resetProfile });
            await db.userSettings.put({
              key: 'user_profile',
              value: resetProfile,
              updatedAt: new Date().toISOString(),
            });
          }
        });
      }

      const savedTheme = (typeof localStorage !== 'undefined' ? (localStorage.getItem('detergent_lab_theme') as LabTheme) : null) || prefRec?.value?.theme || 'midnight';
      applyTheme(savedTheme);

      const savedHardnessHasProvenance = ['USER_ENTERED', 'MEASURED'].includes(String(prefRec?.value?.waterHardnessSource || '').toUpperCase()) &&
        typeof prefRec?.value?.waterHardnessPpm === 'number' && Number.isFinite(prefRec.value.waterHardnessPpm) && prefRec.value.waterHardnessPpm >= 0;
      const loadedPreferences: AppPreferences = {
        ...(prefRec?.value ? { ...DEFAULT_PREFERENCES, ...prefRec.value } : DEFAULT_PREFERENCES),
        waterHardnessPpm: savedHardnessHasProvenance ? prefRec!.value.waterHardnessPpm : null,
        waterHardnessSource: savedHardnessHasProvenance ? prefRec!.value.waterHardnessSource : 'UNKNOWN',
        theme: savedTheme
      };

      set({
        profile: currentProfile,
        aiSettings: aiRec?.value ? { ...DEFAULT_AI_SETTINGS, ...aiRec.value } : DEFAULT_AI_SETTINGS,
        preferences: loadedPreferences,
        syncState: {
          ...get().syncState,
          isCloudConnected: isSupabaseConfigured(),
          lastSyncedAt: CloudSyncService.getStatus().lastSyncedAt,
        },
        isLoading: false,
      });

      // Auto-trigger sync on launch if authenticated
      if (currentProfile.isAuthenticated && isSupabaseConfigured()) {
        CloudSyncService.syncAll(currentProfile.email, currentProfile.id).then((res) => {
          set({
            syncState: {
              lastSyncedAt: CloudSyncService.getStatus().lastSyncedAt,
              isSyncing: false,
              error: res.error || null,
              isCloudConnected: true,
            },
          });
        });
      }
    } catch (err) {
      console.error('Failed to load settings from DB:', err);
      set({ isLoading: false });
    }
  },

  updateProfile: async (updated) => {
    const newProfile = { ...get().profile, ...updated };
    set({ profile: newProfile });
    
    // Save to local Dexie
    await db.userSettings.put({
      key: 'user_profile',
      value: newProfile,
      updatedAt: new Date().toISOString(),
    });

    // If Supabase is connected and user is authenticated, sync to cloud profiles table
    if (isSupabaseConfigured() && newProfile.isAuthenticated && newProfile.id && !newProfile.id.startsWith('guest_')) {
      try {
        const { supabase } = await import('../services/supabaseClient');
        await supabase.from('profiles').upsert({
          id: newProfile.id,
          email: newProfile.email,
          name: newProfile.name,
          company: newProfile.company,
          role: newProfile.role,
          plan: newProfile.plan,
          trial_activated: newProfile.trialActivated,
          trial_ends_at: newProfile.trialEndsAt,
          subscription_expires_at: newProfile.subscriptionExpiresAt,
          updated_at: new Date().toISOString(),
        });
      } catch (err) {
        console.warn('Could not sync profile update to Supabase:', err);
      }
    }
  },

  updateAISettings: async (updated) => {
    const newAISettings = { ...get().aiSettings, ...updated };
    set({ aiSettings: newAISettings });
    await db.userSettings.put({
      key: 'ai_settings',
      value: newAISettings,
      updatedAt: new Date().toISOString(),
    });
  },

  updatePreferences: async (updated) => {
    const newPrefs: AppPreferences = {
      ...get().preferences,
      ...updated,
      waterHardnessSource: updated.waterHardnessPpm !== undefined
        ? (updated.waterHardnessPpm === null ? 'UNKNOWN' : (updated.waterHardnessSource || 'USER_ENTERED'))
        : get().preferences.waterHardnessSource
    };
    set({ preferences: newPrefs });
    await db.userSettings.put({
      key: 'app_preferences',
      value: newPrefs,
      updatedAt: new Date().toISOString(),
    });
  },

  setTheme: async (theme: LabTheme) => {
    applyTheme(theme);
    await get().updatePreferences({ theme });
  },

  toggleTheme: async () => {
    const currentTheme = get().preferences.theme || 'midnight';
    const nextTheme: LabTheme = currentTheme === 'daylight' ? 'midnight' : 'daylight';
    await get().setTheme(nextTheme);
  },

  signIn: async (email: string, password?: string, name?: string) => {
    const normalizedEmail = email.trim();
    if (!normalizedEmail || !password?.trim()) {
      throw new Error('Email and password are required.');
    }
    if (!isSupabaseConfigured()) {
      throw new Error('Email sign-in is unavailable because Supabase is not configured. Continue as a local guest or configure Supabase authentication.');
    }
    const { AuthService } = await import('../services/supabaseClient');
    const authRes = await AuthService.signInWithEmail(normalizedEmail, password);
    if (!authRes.success || !authRes.user || !authRes.session) {
      throw new Error(authRes.error || 'Authentication did not return a valid user session.');
    }
    if (firebaseAuth.currentUser) {
      await firebaseSignOutUser();
    }
    const user = authRes.user;
    const derivedName = user.user_metadata?.name || name || normalizedEmail.split('@')[0] || 'Lab Formulator';
    const updated: Partial<UserProfile> = {
      id: user.id,
      email: user.email || normalizedEmail,
      name: derivedName,
      company: user.user_metadata?.company || get().profile.company || 'R&D Laboratory',
      isAuthenticated: true,
    };
    await get().updateProfile(updated);
    await get().triggerCloudSync();
  },

  signUp: async (email: string, password: string, name: string, company?: string) => {
    const normalizedEmail = email.trim();
    const normalizedName = name.trim();
    if (!normalizedEmail || !password.trim() || !normalizedName) {
      throw new Error('Name, email and password are required.');
    }
    if (!isSupabaseConfigured()) {
      throw new Error('Account sign-up is unavailable because Supabase is not configured. Continue as a local guest or configure Supabase authentication.');
    }
    const { AuthService } = await import('../services/supabaseClient');
    const authRes = await AuthService.signUpWithEmail(normalizedEmail, password, normalizedName, company?.trim());
    if (!authRes.success || !authRes.user) {
      throw new Error(authRes.error || 'Failed to create account.');
    }
    if (authRes.confirmationRequired || !authRes.session) {
      return { confirmationRequired: true };
    }
    if (firebaseAuth.currentUser) {
      await firebaseSignOutUser();
    }
    const updated: Partial<UserProfile> = {
      id: authRes.user.id,
      email: authRes.user.email || normalizedEmail,
      name: authRes.user.user_metadata?.name || normalizedName,
      company: company || 'Detergent Lab',
      isAuthenticated: true,
    };
    await get().updateProfile(updated);
    await get().triggerCloudSync();
    return { confirmationRequired: false };
  },

  signInWithGoogle: async () => {
    try {
      const user = await firebaseSignInWithGoogle();
      if (user) {
        if (hasPersistedSupabaseSession()) {
          const { AuthService } = await import('../services/supabaseClient');
          await AuthService.signOut();
        }
        const updated: Partial<UserProfile> = {
          id: user.uid,
          email: user.email || '',
          name: user.displayName || 'Formulation Chemist',
          isAuthenticated: true,
        };
        await get().updateProfile(updated);
        const { syncUserProfile } = await import('../services/firebaseClient');
        await syncUserProfile(user);
        await get().triggerCloudSync();
      }
    } catch (err: any) {
      console.error('Firebase Google Sign-In error:', err);
      if (isSupabaseConfigured()) {
        const { AuthService } = await import('../services/supabaseClient');
        const authRes = await AuthService.signInWithGoogle();
        if (!authRes.success) {
          throw new Error(authRes.error || 'Google Sign-In failed.');
        }
      } else {
        throw new Error(err?.message || 'Google Sign-In failed via Firebase Auth.');
      }
    }
  },

  signOut: async () => {
    try {
      await firebaseSignOutUser();
    } catch (e) {
      console.warn('Firebase sign out error:', e);
    }
    if (hasPersistedSupabaseSession()) {
      const { AuthService } = await import('../services/supabaseClient');
      await AuthService.signOut();
    }
    const resetProf: UserProfile = {
      ...DEFAULT_PROFILE,
      isAuthenticated: false,
    };
    set({ profile: resetProf });
    await db.userSettings.put({
      key: 'user_profile',
      value: resetProf,
      updatedAt: new Date().toISOString(),
    });
  },

  activate7DayTrial: async () => {
    const trialDays = 7;
    const expires = new Date();
    expires.setDate(expires.getDate() + trialDays);

    const updated: Partial<UserProfile> = {
      plan: 'pro_monthly',
      trialActivated: true,
      trialEndsAt: expires.toISOString(),
      subscriptionExpiresAt: expires.toISOString(),
    };
    await get().updateProfile(updated);
  },

  upgradePlan: async (plan: UserPlan, verificationToken?: string) => {
    if (plan === 'free') {
      const updated: Partial<UserProfile> = {
        plan: 'free',
        subscriptionExpiresAt: null,
      };
      await get().updateProfile(updated);
      return;
    }

    // Strict Fail-Closed Billing Security:
    // Client-side UI state must never be the authority for paid entitlements.
    if (!verificationToken) {
      throw new Error(
        'Billing verification incomplete: Server-side purchase verification is required to grant paid entitlements. Unverified client claims are rejected.'
      );
    }

    const expiry = new Date();
    if (plan === 'pro_yearly' || plan === 'team') {
      expiry.setFullYear(expiry.getFullYear() + 1);
    } else {
      expiry.setMonth(expiry.getMonth() + 1);
    }

    const updated: Partial<UserProfile> = {
      plan,
      subscriptionExpiresAt: expiry.toISOString(),
    };

    // Auto-initialize team workspace if upgraded to team plan
    if (plan === 'team' && !get().profile.teamWorkspace) {
      updated.teamWorkspace = {
        id: `team_${Date.now()}`,
        name: `${get().profile.company || 'Chemical'} R&D Team`,
        ownerEmail: get().profile.email,
        createdAt: new Date().toISOString(),
        members: [
          {
            email: get().profile.email,
            name: get().profile.name,
            role: 'owner',
            status: 'active',
            joinedAt: new Date().toISOString(),
          },
        ],
      };
    }

    await get().updateProfile(updated);
  },

  createTeamWorkspace: async (teamName: string) => {
    const workspace: TeamWorkspace = {
      id: `team_${Date.now()}`,
      name: teamName,
      ownerEmail: get().profile.email,
      createdAt: new Date().toISOString(),
      members: [
        {
          email: get().profile.email,
          name: get().profile.name,
          role: 'owner',
          status: 'active',
          joinedAt: new Date().toISOString(),
        },
      ],
    };
    await get().updateProfile({ teamWorkspace: workspace, plan: 'team' });
  },

  inviteTeamMember: async (email: string, role: 'chemist' | 'viewer' = 'chemist') => {
    const currentWs = get().profile.teamWorkspace;
    if (!currentWs) return;

    if (currentWs.members.length >= 5) {
      throw new Error('Team limit reached (max 5 members on Team plan).');
    }

    if (currentWs.members.some((m) => m.email.toLowerCase() === email.toLowerCase())) {
      throw new Error('Member already exists in team workspace.');
    }

    const newMember: TeamMember = {
      email,
      name: email.split('@')[0],
      role,
      status: 'invited',
      joinedAt: new Date().toISOString(),
    };

    const updatedWs: TeamWorkspace = {
      ...currentWs,
      members: [...currentWs.members, newMember],
    };

    await get().updateProfile({ teamWorkspace: updatedWs });
  },

  removeTeamMember: async (email: string) => {
    const currentWs = get().profile.teamWorkspace;
    if (!currentWs) return;

    const updatedMembers = currentWs.members.filter((m) => m.email.toLowerCase() !== email.toLowerCase());
    const updatedWs: TeamWorkspace = {
      ...currentWs,
      members: updatedMembers,
    };

    await get().updateProfile({ teamWorkspace: updatedWs });
  },

  triggerCloudSync: async () => {
    set({ syncState: { ...get().syncState, isSyncing: true, error: null } });
    const currentUser = firebaseAuth.currentUser;

    if (currentUser) {
      try {
        const { saveUserFormula, saveUserTrial } = await import('../services/firebaseClient');
        const allFormulas = await db.formulas.toArray();
        for (const f of allFormulas) {
          await saveUserFormula(currentUser.uid, f);
        }
        const allNotes = await db.labNotes.toArray();
        for (const n of allNotes) {
          await saveUserTrial(currentUser.uid, {
            id: n.id,
            title: n.title,
            observations: n.text,
            formulaId: n.formulaId,
            updatedAt: n.updatedAt,
            createdAt: n.createdAt,
          });
        }
        set({
          syncState: {
            lastSyncedAt: new Date().toLocaleTimeString(),
            isSyncing: false,
            error: null,
            isCloudConnected: true,
          },
        });
        return;
      } catch (e: any) {
        console.error('Firestore cloud sync failed:', e);
        set({
          syncState: {
            ...get().syncState,
            isSyncing: false,
            error: e.message || 'Firestore sync failed',
          },
        });
        return;
      }
    }

    const res = await CloudSyncService.syncAll(get().profile.email, get().profile.id);
    set({
      syncState: {
        lastSyncedAt: CloudSyncService.getStatus().lastSyncedAt,
        isSyncing: false,
        error: res.error || null,
        isCloudConnected: isSupabaseConfigured(),
      },
    });
  },

  deleteAccount: async () => {
    const userId = get().profile.id;
    const { AuthService } = await import('../services/supabaseClient');
    const deletion = await AuthService.deleteAccount(userId);
    if (!deletion.success) {
      throw new Error(deletion.error || 'Account deletion could not be verified.');
    }
    // Firebase identities are removed server-side; clear the local Firebase session too.
    try { await firebaseSignOutUser(); } catch (error) { console.warn('Firebase sign-out after account deletion failed:', error); }
    await CloudSyncService.purgeUserData(userId);
    const resetProf: UserProfile = {
      ...DEFAULT_PROFILE,
      isAuthenticated: false,
    };
    set({ profile: resetProf });
    await db.userSettings.clear();
  },
}));
