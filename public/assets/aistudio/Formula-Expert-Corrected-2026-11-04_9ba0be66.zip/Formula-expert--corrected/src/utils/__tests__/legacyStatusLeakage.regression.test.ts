import { evaluateScientificQualityGate } from '../scientificQualityGateEngine';

interface TestResult {
  group: string;
  name: string;
  passed: boolean;
  message?: string;
  actual?: any;
  expected?: any;
}

export function runLegacyStatusLeakageTestSuite() {
  const results: TestResult[] = [];

  function assert(group: string, name: string, condition: boolean, actual: any, expected: any) {
    results.push({
      group,
      name,
      passed: condition,
      actual,
      expected,
      message: condition ? 'PASSED' : `FAILED (Expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)})`
    });
  }

  // A. Imported formula with: status = COMMERCIAL_READY. Current Quality Gate: NEEDS_ADJUSTMENT/OUT_OF_SPEC/INCOMPATIBLE.
  const formulaA: any = {
    id: 'imported-A',
    name: 'Dilute Slop',
    category: 'LAUNDRY_LIQUID',
    batchSizeKg: 100,
    targetPH: 7.0,
    description: 'A dilute slop formulation',
    instructions: ['Mix water and surfactants'],
    status: 'COMMERCIAL_READY', // legacy status
    ingredients: [
      { name: 'Water', percentage: 99.5, category: 'Solvent' },
      { name: 'SLES 70%', percentage: 0.5, activeMatterPct: 70, category: 'Surfactant' }
    ]
  };

  const gateA = evaluateScientificQualityGate({
    ingredients: formulaA.ingredients,
    productCategory: formulaA.category,
    formulaName: formulaA.name,
    formulaVersion: '1.0.0'
  });

  assert(
    'A. Stale COMMERCIAL_READY Precedence',
    'COMMERCIAL_READY legacy status cannot bypass actual Quality Gate output',
    gateA.finalFormulaStatus === 'OUT_OF_SPEC' || gateA.finalFormulaStatus === 'INCOMPATIBLE' || gateA.finalFormulaStatus === 'INSUFFICIENT_DATA',
    gateA.finalFormulaStatus,
    'OUT_OF_SPEC / INCOMPATIBLE'
  );

  // B. Imported formula with: status = VALID. Current Quality Gate: LAB_VALIDATION_REQUIRED
  // Let's pass a formula that is theoretically valid and compatible but requires lab validation (unmeasured R&D candidate)
  const formulaB: any = {
    id: 'imported-B',
    name: 'Theoretical Mix',
    category: 'LAUNDRY_LIQUID',
    batchSizeKg: 100,
    targetPH: 7.0,
    description: 'A theoretical mix formulation',
    instructions: ['Mix ingredients'],
    status: 'VALID', // legacy status
    ingredients: [
      { name: 'Water', percentage: 66.02, activeMatterPct: 0, category: 'Solvent' },
      { name: 'LABSA 90%', percentage: 13.5, activeMatterPct: 90, category: 'Anionic Surfactant' },
      { name: 'Sodium Hydroxide 50%', percentage: 2.98, activeMatterPct: 50, category: 'pH Adjuster' },
      { name: 'GLDA-47', percentage: 16.5, activeMatterPct: 47, category: 'Chelator' },
      { name: 'Sodium Bicarbonate', percentage: 1, activeMatterPct: 100, category: 'Builder' }
    ]
  };

  const gateB = evaluateScientificQualityGate({
    ingredients: formulaB.ingredients,
    productCategory: formulaB.category,
    formulaName: formulaB.name,
    formulaVersion: '1.0.0',
    waterHardnessPpm: 50,
    washVolumeL: 10,
    washDoseGrams: 50,
    batchSizeKg: 100
  });

  assert(
    'B. Stale VALID Precedence',
    'Legacy VALID status cannot bypass the current INCOMPATIBLE scientific gate',
    gateB.finalFormulaStatus === 'INCOMPATIBLE',
    gateB.finalFormulaStatus,
    'INCOMPATIBLE'
  );

  // C. Imported formula with: status = PRODUCTION_READY. Current Quality Gate: OUT_OF_SPEC / NEEDS_ADJUSTMENT
  const formulaC: any = {
    id: 'imported-C',
    name: 'Out of Spec Mix',
    category: 'LAUNDRY_LIQUID',
    batchSizeKg: 100,
    targetPH: 7.0,
    description: 'An out of spec mix formulation',
    instructions: ['Mix ingredients'],
    status: 'PRODUCTION_READY',
    ingredients: [
      { name: 'Water', percentage: 50, category: 'Solvent' },
      { name: 'SLES 70%', percentage: 50, activeMatterPct: 70, category: 'Surfactant' } // overly high actives, out of spec
    ]
  };

  const gateC = evaluateScientificQualityGate({
    ingredients: formulaC.ingredients,
    productCategory: formulaC.category,
    formulaName: formulaC.name,
    formulaVersion: '1.0.0'
  });

  assert(
    'C. Stale PRODUCTION_READY Precedence',
    'PRODUCTION_READY legacy status cannot force out-of-spec formula to pass',
    gateC.finalFormulaStatus === 'OUT_OF_SPEC' || gateC.finalFormulaStatus === 'INCOMPATIBLE',
    gateC.finalFormulaStatus,
    'OUT_OF_SPEC'
  );

  // D. Formula with no status does not get auto-approved
  const formulaD: any = {
    id: 'imported-D',
    name: 'Blank status',
    category: 'LAUNDRY_LIQUID',
    batchSizeKg: 100,
    targetPH: 7.0,
    description: 'A formula with no status',
    instructions: ['Mix ingredients'],
    ingredients: []
  };

  const gateD = evaluateScientificQualityGate({
    ingredients: formulaD.ingredients,
    productCategory: formulaD.category,
    formulaName: formulaD.name,
    formulaVersion: '1.0.0'
  });

  assert(
    'D. No Status Fallback',
    'Blank status does not default to VALID or COMMERCIAL_READY',
    (gateD.finalFormulaStatus as string) !== 'VALID' && (gateD.finalFormulaStatus as string) !== 'COMMERCIAL_READY',
    gateD.finalFormulaStatus,
    'non-VALID/non-COMMERCIAL_READY'
  );

  // F. Historical metadata preservation
  const preservationCheck = formulaA.status === 'COMMERCIAL_READY';
  assert(
    'F. Historical Metadata',
    'Legacy status can be preserved as historical metadata, but is separate from Quality Gate authority',
    preservationCheck,
    formulaA.status,
    'COMMERCIAL_READY'
  );

  results.filter(r => !r.passed).forEach(r => console.log(`[FAIL] [${r.group}] ${r.name} :: actual=${JSON.stringify(r.actual)} expected=${JSON.stringify(r.expected)} message=${r.message}`));
  const passedCount = results.filter(r => r.passed).length;
  const failedCount = results.filter(r => !r.passed).length;

  results.forEach(r => {
    const icon = r.passed ? '✓' : '✗';
    console.log(`  ${icon} [${r.group}] ${r.name}: ${r.message}`);
  });

  console.log(`\nLegacy Status Leakage Suite: ${passedCount}/${results.length} PASSED (${failedCount} FAILED)`);

  return {
    passed: passedCount,
    failed: failedCount,
    total: results.length,
    results
  };
}
