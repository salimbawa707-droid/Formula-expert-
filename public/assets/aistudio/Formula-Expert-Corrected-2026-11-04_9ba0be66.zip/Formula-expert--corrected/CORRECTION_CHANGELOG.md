# Correction Changelog — 2026-11-04

## Security / API
- Removed global 30 MB JSON parsing and applied bounded per-route JSON parsers.
- Added authentication and per-IP in-memory rate limits to AI and purchase-verification endpoints.
- Added input size/type/range checks for AI chat, label OCR, ingredient research, and researched ingredient application.
- Added generic JSON responses for malformed/oversized request bodies and stopped returning raw exception messages.
- Added explicit authenticated HTTP 501 response for `/api/account` until provider-aware deletion can be implemented safely.

## AI / chemical data integrity
- AI-researched ingredients returned by `/api/ai/apply-verified-ingredient` remain `UNVERIFIED` with `AI_RESEARCH_PENDING_REVIEW` provenance.
- Added `/api/ai/analyze-recommend` because the frontend called this endpoint but no backend route was present in `server.ts`.
- Added recommendation disclaimer: AI recommendations are hypotheses and are not laboratory, safety, regulatory, cost, or environmental certifications.

## Billing
- Added `/api/billing/verify-purchase`.
- Server binds purchase verification to the authenticated user UID and canonical package name; failed or unavailable Google Play verification grants no entitlement.

## Frontend
- Replaced `dangerouslySetInnerHTML` for molecular SVG depiction with an encoded SVG loaded through an `<img>` element.

## Runtime / verification
- Declared Node.js `>=22.6.0` and made the TypeScript stripping flag explicit in `dev` and `start`.
- Added `scripts/verify-correction-static.mjs` and `test:correction-static` script.
- Added Hindi correction guide, post-correction audit, Android build guide, and remaining-issues list.
- Updated the release manifest so earlier verification evidence is not misrepresented as current release certification.

## Not claimed
- No full dependency installation, Vite build, existing Bun regression suite, live API integration test, Android APK build, dependency vulnerability scan, or laboratory validation was performed in this environment.
