# Android Build & Deployment Guide

This guide is a checklist, not proof that a build has passed.

## 1. Runtime and dependencies
1. Use Node.js >=22.6.0 for the corrected server start command.
2. Use the package manager intended by this repository (`bun.lock` is present). Install dependencies in a controlled development environment.
3. Run the static correction check: `node scripts/verify-correction-static.mjs`.
4. Run the existing project test scripts and `vite build`. Save logs and commit hashes with the result.

## 2. Backend configuration
- Keep `GEMINI_API_KEY` in the backend secret manager only; do not prefix it with `VITE_`.
- Configure Firebase/Supabase authentication verification as required by `src/services/serverSecurity.ts`.
- Configure Google Play Developer API credentials securely before expecting subscriptions to verify.
- Use HTTPS in production.
- Configure `VITE_API_BASE_URL` for the Android build to point to the real HTTPS backend. Do not ship a placeholder URL.
- Verify that authenticated requests include a valid Bearer token and that unauthenticated calls receive 401.

## 3. Android debug build
From the project root, use the repository’s existing script after dependencies and Android SDK/Gradle prerequisites are installed:
```bash
bun run android:debug
```
The script runs Capacitor sync and `scripts/build_android_debug.mjs`. Inspect its output and verify the APK file was actually produced. The script command existing in `package.json` is not evidence of a successful build.

## 4. Device smoke tests
- Login and logout.
- Chat, formula recommendations, ingredient research, and label scan.
- Try oversized/malformed payloads and verify clean 400/413/429 responses.
- Confirm AI-researched ingredient remains visibly unverified until a human checks the source.
- Test purchase verification with a genuine test subscription and failure cases; never use a fabricated token to grant access.
- Verify API reachability with mobile data and Wi-Fi.
- Test offline navigation separately; AI/billing/backend-dependent features should report unavailable rather than pretend to work.

## 5. Release checklist
Do not publish until the production build, regression tests, security review, account-deletion workflow, Google Play billing, signing, privacy policy, and scientific/lab validation gates are complete. Store signing keys and service-account credentials outside source control.
